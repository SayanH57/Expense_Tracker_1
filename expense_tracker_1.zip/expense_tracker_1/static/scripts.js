document.addEventListener('DOMContentLoaded', () => {
  const expenseForm = document.getElementById('expense-form');
  const expenseList = document.getElementById('expense-list');

  // Chart.js chart instances
  let monthlyChart = null;
  let categoryChart = null;

  // Format date as YYYY-MM-DD
  function formatDate(date) {
    return date.toISOString().split('T')[0];
  }

  // Render the list of expenses
  function renderExpenseList(expenses) {
    if (!expenses.length) {
      expenseList.innerHTML = `<p>No expenses recorded yet.</p>`;
      return;
    }

    // Build expense item HTML
    const fragment = document.createDocumentFragment();

    expenses.forEach((exp) => {
      const item = document.createElement('div');
      item.className = 'expense-item';
      item.setAttribute('data-id', exp.id);

      const info = document.createElement('div');
      info.className = 'expense-info';

      const dateSpan = document.createElement('span');
      dateSpan.textContent = new Date(exp.date).toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });

      const amountSpan = document.createElement('span');
      amountSpan.textContent = `$${exp.amount.toFixed(2)}`;
      amountSpan.style.fontWeight = '600';
      amountSpan.style.minWidth = '80px';
      amountSpan.style.textAlign = 'right';

      const descSpan = document.createElement('span');
      descSpan.textContent = exp.description || '-';
      descSpan.style.flexGrow = '1';
      descSpan.style.whiteSpace = 'nowrap';
      descSpan.style.overflow = 'hidden';
      descSpan.style.textOverflow = 'ellipsis';
      descSpan.title = exp.description || '';

      const catSpan = document.createElement('span');
      catSpan.className = 'cat-badge';
      catSpan.textContent = capitalizeFirstLetter(exp.category);

      info.appendChild(dateSpan);
      info.appendChild(catSpan);
      info.appendChild(descSpan);
      info.appendChild(amountSpan);

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'expense-delete-btn';
      deleteBtn.setAttribute('aria-label', `Delete expense of ${exp.amount} on ${dateSpan.textContent}`);
      deleteBtn.innerHTML = '&times;';
      deleteBtn.addEventListener('click', () => deleteExpense(exp.id));

      item.appendChild(info);
      item.appendChild(deleteBtn);

      fragment.appendChild(item);
    });

    expenseList.innerHTML = '';
    expenseList.appendChild(fragment);
  }

  // Capitalize first letter helper
  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  // Fetch expenses from backend
  async function fetchExpenses() {
    try {
      const res = await fetch('/api/expenses');
      if (!res.ok) throw new Error('Failed to load expenses');
      const data = await res.json();
      renderExpenseList(data);
    } catch (err) {
      expenseList.innerHTML = `<p class="error-message">Error loading expenses.</p>`;
      console.error(err);
    }
  }

  // Add expense via API
  async function addExpense(expense) {
    try {
      const res = await fetch('/api/expenses', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(expense),
      });
      if (!res.ok) {
        const errorResp = await res.json();
        throw new Error(errorResp.error || 'Failed to add expense');
      }
      const data = await res.json();
      return data;
    } catch (err) {
      alert(`Error adding expense: ${err.message}`);
      throw err;
    }
  }

  // Delete expense via API
  async function deleteExpense(id) {
    if (!confirm('Are you sure you want to delete this expense?')) return;
    try {
      const res = await fetch('/api/expenses', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) {
        const errorResp = await res.json();
        throw new Error(errorResp.error || 'Failed to delete expense');
      }
      await fetchExpenses();
      // Refresh charts
      await loadStatistics();
    } catch (err) {
      alert(`Error deleting expense: ${err.message}`);
    }
  }

  // Load and update the charts
  async function loadStatistics() {
    try {
      const res = await fetch('/api/statistics');
      if (!res.ok) throw new Error('Failed to fetch statistics');
      const stats = await res.json();
      updateMonthlyChart(stats.monthly);
      updateCategoryChart(stats.category, stats.category_labels);
    } catch (err) {
      console.error('Error loading statistics:', err);
    }
  }

  // Initialize or update the monthly spending bar chart
  function updateMonthlyChart(data) {
    const ctx = document.getElementById('monthly-spending-chart').getContext('2d');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    if (monthlyChart) {
      monthlyChart.data.datasets[0].data = data;
      monthlyChart.update();
    } else {
      monthlyChart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: months,
          datasets: [{
            label: 'Amount ($)',
            data,
            backgroundColor: 'rgba(37, 99, 235, 0.7)',
            borderRadius: 4,
            barPercentage: 0.6,
          }],
        },
        options: {
          responsive: true,
          plugins: {
            legend: { display: false },
            tooltip: { enabled: true },
          },
          scales: {
            y: {
              beginAtZero: true,
              ticks: {
                color: '#6b7280',
              },
              grid: { color: '#e5e7eb' },
            },
            x: {
              ticks: { color: '#6b7280' },
              grid: { display: false },
            },
          },
        },
      });
    }
  }

  // Initialize or update the category spending pie chart
  function updateCategoryChart(data, labels) {
    const ctx = document.getElementById('category-spending-chart').getContext('2d');
    if (categoryChart) {
      categoryChart.data.datasets[0].data = data;
      categoryChart.update();
    } else {
      const colors = [
        '#2563eb', // blue
        '#ef4444', // red
        '#fbbf24', // amber
        '#10b981', // green
        '#8b5cf6', // purple
        '#ec4899', // pink
      ];
      categoryChart = new Chart(ctx, {
        type: 'pie',
        data: {
          labels,
          datasets: [{
            data,
            backgroundColor: colors.slice(0, labels.length),
            hoverOffset: 10,
          }],
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'bottom',
              labels: { color: '#6b7280' },
            },
            tooltip: { enabled: true },
          },
        },
      });
    }
  }

  // Handle form submit for adding expense
  expenseForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(expenseForm);

    const amount = parseFloat(formData.get('amount'));
    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid positive amount.');
      return;
    }

    let category = formData.get('category');
    if (!category) {
      alert('Please select a category.');
      return;
    }

    const date = formData.get('date') || formatDate(new Date());
    const description = formData.get('description').trim();

    const expense = { amount, category, date, description };

    try {
      await addExpense(expense);
      expenseForm.reset();
      // Reset date input to today after reset (for user convenience)
      expenseForm.querySelector('#date').value = formatDate(new Date());
      await fetchExpenses();
      await loadStatistics();
    } catch {
      // Error already alerted in addExpense
    }
  });

  // Initialize date input default to today
  expenseForm.querySelector('#date').value = formatDate(new Date());

  // Initialization: fetch and render data and charts
  (async () => {
    await fetchExpenses();
    await loadStatistics();
  })();
});


