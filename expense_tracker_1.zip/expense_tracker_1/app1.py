from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from functools import wraps
from datetime import datetime
import uuid

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with a secure key

# In-memory data stores for demonstration (replace with persistent DB if needed)
users = {}
expenses = {}
categories = {
    'food': 'Food',
    'transport': 'Transport',
    'entertainment': 'Entertainment',
    'utilities': 'Utilities',
    'others': 'Others'
}

# Helper: login required decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def home():
    if 'user' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'user' in session:
        return redirect(url_for('dashboard'))
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        if username in users and users[username]['password'] == password:
            session['user'] = username
            return redirect(url_for('dashboard'))
        else:
            error = 'Invalid username or password.'
    return render_template('login.html', error=error)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if 'user' in session:
        return redirect(url_for('dashboard'))
    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '').strip()
        confirm = request.form.get('confirm', '').strip()
        if not username or not password:
            error = 'Username and password are required.'
        elif password != confirm:
            error = 'Passwords do not match.'
        elif username in users:
            error = 'Username already exists.'
        else:
            users[username] = {'password': password}
            expenses[username] = []
            session['user'] = username
            return redirect(url_for('dashboard'))
    return render_template('signup.html', error=error)

@app.route('/logout')
@login_required
def logout():
    session.pop('user', None)
    return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('index.html', categories=categories)

# API routes for managing expenses

@app.route('/api/expenses', methods=['GET', 'POST', 'DELETE'])
@login_required
def api_expenses():
    user = session['user']
    if user not in expenses:
        expenses[user] = []
    if request.method == 'GET':
        return jsonify(expenses[user])
    elif request.method == 'POST':
        data = request.json
        # Validate data
        try:
            amount = float(data['amount'])
            category = data['category']
            description = data.get('description', '')
            date_str = data.get('date', '')
            if category not in categories:
                return jsonify({'error': 'Invalid category'}), 400
            if date_str:
                date = datetime.strptime(date_str, '%Y-%m-%d').date()
            else:
                date = datetime.now().date()
            expense_id = str(uuid.uuid4())
            expense = {
                'id': expense_id,
                'amount': amount,
                'category': category,
                'description': description,
                'date': date.isoformat()
            }
            expenses[user].append(expense)
            return jsonify(expense)
        except (ValueError, KeyError):
            return jsonify({'error': 'Invalid data'}), 400
    elif request.method == 'DELETE':
        data = request.json
        expense_id = data.get('id')
        if not expense_id:
            return jsonify({'error': 'Expense ID required'}), 400
        user_expenses = expenses.get(user, [])
        new_expenses = [e for e in user_expenses if e['id'] != expense_id]
        if len(new_expenses) == len(user_expenses):
            return jsonify({'error': 'Expense not found'}), 404
        expenses[user] = new_expenses
        return jsonify({'success': True})
    return jsonify({'error': 'Method not allowed'}), 405

@app.route('/api/categories', methods=['GET'])
@login_required
def api_categories():
    return jsonify(categories)

@app.route('/api/statistics', methods=['GET'])
@login_required
def api_statistics():
    user = session['user']
    user_expenses = expenses.get(user, [])
    # Aggregate monthly spending and spending by categories in the current year
    monthly_totals = {month: 0 for month in range(1, 13)}
    category_totals = {cat: 0 for cat in categories}
    now = datetime.now()

    for exp in user_expenses:
        try:
            exp_date = datetime.strptime(exp['date'], '%Y-%m-%d').date()
            if exp_date.year == now.year:
                monthly_totals[exp_date.month] += exp['amount']
                category_totals[exp['category']] += exp['amount']
        except:
            pass

    # Format data lists for chart consumption
    monthly_data = [monthly_totals[m] for m in range(1, 13)]
    category_data = [category_totals[cat] for cat in categories]

    return jsonify({
        'monthly': monthly_data,
        'category': category_data,
        'category_labels': list(categories.values())
    })

if __name__ == '__main__':
    app.run(debug=True)

